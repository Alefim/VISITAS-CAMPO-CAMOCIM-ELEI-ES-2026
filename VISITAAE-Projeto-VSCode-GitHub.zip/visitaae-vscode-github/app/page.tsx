"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import territoriosData from "./data/territorios.json";

type Territorio = { bairro: string; ruas: string[] };
type VisitForm = {
  visitante: string; bairro: string; rua: string; numero: string; morador: string;
  situacao: string; retorno: string; telefone: string; observacoes: string;
  tipoVisita: string; deputadoEstadual: string; deputadoFederal: string;
  senador: string; governador: string; presidente: string;
  latitude: number | null; longitude: number | null;
};
type SentVisit = { id: string; bairro: string; rua: string; situacao: string; tipoVisita: string; horario: string };

const territorios = territoriosData as Territorio[];
const SHEET_URL = "https://docs.google.com/spreadsheets/d/12T83SbGMwPGLp_ZHJvpHun2mVdas46o0VkYRIb33QI8/edit";
const ENDPOINT_KEY = "visitaae_google_sheets_endpoint";
const INTEGRATION_VERSION_KEY = "visitaae_integration_version";
const INTEGRATION_VERSION = "2";
const VISITOR_KEY = "visitaae_visitante";
const situacoes = ["Visitado", "Casa fechada", "Ausente", "Recusou", "Reagendar"];
const candidatos = {
  deputadoEstadual: ["Sergio Aguiar", "João Jaime", "Romeu", "Outros/Indecisos"],
  deputadoFederal: ["Leonidas", "Heitor Freire", "Zé Ayrton", "Outros/Indecisos"],
  senador: ["Érica/Mônica", "Camilo", "Outros/Indecisos"],
  governador: ["Roberto Cláudio", "Capitão Wagner", "Elmano", "Outros/Indecisos"],
  presidente: ["Ciro", "Lula", "Bolsonaro", "Outros/Indecisos"],
} as const;
const appsScriptCode = [
  "const SPREADSHEET_ID = '12T83SbGMwPGLp_ZHJvpHun2mVdas46o0VkYRIb33QI8';",
  "const SHEET_NAME = 'Coletas';", "", "function doPost(e) {",
  "  const lock = LockService.getScriptLock();", "  lock.waitLock(10000);", "  try {",
  "    const data = JSON.parse(e.postData.contents);",
  "    const sheet = SpreadsheetApp.openById(SPREADSHEET_ID).getSheetByName(SHEET_NAME);",
  "    sheet.appendRow([", "      data.id, new Date(data.dataHora), data.visitante, data.bairro, data.rua,",
  "      data.numero, data.morador, data.situacao, data.retorno, data.telefone,",
  "      data.observacoes, data.latitude, data.longitude, 'Sistema VISITAAE', new Date(),",
  "      data.tipoVisita, data.deputadoEstadual, data.deputadoFederal,",
  "      data.senador, data.governador, data.presidente",
  "    ]);", "    return ContentService.createTextOutput(JSON.stringify({ ok: true }))",
  "      .setMimeType(ContentService.MimeType.JSON);", "  } finally {", "    lock.releaseLock();", "  }", "}", "",
  "function doGet() {", "  return ContentService.createTextOutput('VISITAAE conectado');", "}",
].join("\n");

const emptyForm: VisitForm = {
  visitante: "", bairro: "", rua: "", numero: "", morador: "", situacao: "Visitado",
  retorno: "Não", telefone: "", observacoes: "", latitude: null, longitude: null,
  tipoVisita: "1ª visita", deputadoEstadual: "", deputadoFederal: "", senador: "",
  governador: "", presidente: "",
};
const makeId = () => `VIS-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;

export default function Home() {
  const [form, setForm] = useState<VisitForm>(emptyForm);
  const [endpoint, setEndpoint] = useState("");
  const [integrationVersion, setIntegrationVersion] = useState("");
  const [endpointDraft, setEndpointDraft] = useState("");
  const [showSetup, setShowSetup] = useState(false);
  const [copied, setCopied] = useState(false);
  const [sending, setSending] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [sentVisits, setSentVisits] = useState<SentVisit[]>([]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      const savedEndpoint = window.localStorage.getItem(ENDPOINT_KEY) ?? "";
      const savedVersion = window.localStorage.getItem(INTEGRATION_VERSION_KEY) ?? "";
      const savedVisitor = window.localStorage.getItem(VISITOR_KEY) ?? "";
      setEndpoint(savedEndpoint); setEndpointDraft(savedEndpoint);
      setIntegrationVersion(savedVersion);
      setForm((current) => ({ ...current, visitante: savedVisitor }));
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  const streets = useMemo(() => territorios.find((item) => item.bairro === form.bairro)?.ruas ?? [], [form.bairro]);
  const hasEndpoint = endpoint.startsWith("https://script.google.com/macros/s/") && endpoint.includes("/exec");
  const connected = hasEndpoint && integrationVersion === INTEGRATION_VERSION;
  const updateField = <K extends keyof VisitForm>(field: K, value: VisitForm[K]) => {
    setForm((current) => ({ ...current, [field]: value })); setMessage(null);
  };

  function saveEndpoint() {
    const value = endpointDraft.trim();
    if (!value.startsWith("https://script.google.com/macros/s/") || !value.includes("/exec")) {
      setMessage({ type: "error", text: "Cole o link da implantação que termina em /exec." }); return;
    }
    window.localStorage.setItem(ENDPOINT_KEY, value);
    window.localStorage.setItem(INTEGRATION_VERSION_KEY, INTEGRATION_VERSION);
    setEndpoint(value); setIntegrationVersion(INTEGRATION_VERSION); setShowSetup(false);
    setMessage({ type: "success", text: "Integração configurada. O próximo registro será enviado à planilha." });
  }

  async function copyScript() {
    await navigator.clipboard.writeText(appsScriptCode); setCopied(true);
    window.setTimeout(() => setCopied(false), 2200);
  }

  function captureLocation() {
    if (!navigator.geolocation) { setMessage({ type: "error", text: "Este aparelho não oferece localização." }); return; }
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => { setForm((c) => ({ ...c, latitude: coords.latitude, longitude: coords.longitude })); setMessage({ type: "success", text: "Localização adicionada ao registro." }); },
      () => setMessage({ type: "error", text: "Não foi possível obter a localização. Verifique a permissão do navegador." }),
      { enableHighAccuracy: true, timeout: 12000 },
    );
  }

  async function submitVisit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!connected) { setShowSetup(true); setMessage({ type: "error", text: "Conecte o Google Sheets antes de registrar a visita." }); return; }
    if (!form.visitante.trim() || !form.bairro || !form.rua || !form.situacao || !form.tipoVisita) {
      setMessage({ type: "error", text: "Preencha visitante, bairro, rua, tipo e situação da visita." }); return;
    }
    setSending(true); setMessage(null);
    const id = makeId(); const now = new Date(); const payload = { id, dataHora: now.toISOString(), ...form };
    try {
      await fetch(endpoint, { method: "POST", mode: "no-cors", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify(payload) });
      window.localStorage.setItem(VISITOR_KEY, form.visitante.trim());
      setSentVisits((current) => [{ id, bairro: form.bairro, rua: form.rua, situacao: form.situacao, tipoVisita: form.tipoVisita, horario: now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }) }, ...current].slice(0, 6));
      setForm((current) => ({ ...emptyForm, visitante: current.visitante, bairro: current.bairro }));
      setMessage({ type: "success", text: `Visita ${id} enviada para a aba Coletas.` });
    } catch { setMessage({ type: "error", text: "Não foi possível enviar. Confira a internet e a conexão da planilha." }); }
    finally { setSending(false); }
  }

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand-wrap"><div className="brand-mark" aria-hidden="true">V</div><div><p className="eyebrow">Controle de campo</p><h1>VISITAAE</h1></div></div>
        <div className="header-actions">
          <span className={`connection-badge ${connected ? "is-connected" : ""}`}><span className="status-dot" />{connected ? "Planilha conectada" : hasEndpoint ? "Atualização necessária" : "Aguardando conexão"}</span>
          <button className="button button-ghost" type="button" onClick={() => setShowSetup(true)}>Configurar</button>
        </div>
      </header>

      <section className="hero-grid">
        <div><p className="hero-kicker">Visitas por bairro e rua</p><h2>Registre cada visita no local, sem perder nenhuma informação.</h2><p className="hero-copy">Selecione o bairro, escolha uma das ruas cadastradas e envie o resultado diretamente para o Google Sheets.</p></div>
        <div className="stats"><article><strong>15</strong><span>bairros e áreas</span></article><article><strong>442</strong><span>ruas e localidades</span></article><article><strong>{sentVisits.length}</strong><span>envios nesta sessão</span></article></div>
      </section>

      {!connected && <section className="setup-banner"><div><strong>{hasEndpoint ? "Atualize a conexão com o Google Sheets" : "Falta apenas conectar o Google Sheets"}</strong><p>{hasEndpoint ? "O formulário ganhou novas colunas. Atualize o código para salvar visita e candidatos." : "A base já está pronta. Faça a configuração uma única vez neste aparelho."}</p></div><button className="button button-primary" type="button" onClick={() => setShowSetup(true)}>{hasEndpoint ? "Atualizar agora" : "Conectar agora"}</button></section>}

      <div className="content-grid">
        <section className="form-card">
          <div className="section-heading"><div><span className="step-label">Novo registro</span><h3>Dados da visita</h3></div><span className="required-note">* campos obrigatórios</span></div>
          {message && <div className={`alert ${message.type}`}>{message.text}</div>}
          <form onSubmit={submitVisit}>
            <div className="form-grid two-columns">
              <label className="field"><span>Visitante *</span><input value={form.visitante} onChange={(e) => updateField("visitante", e.target.value)} placeholder="Nome da pessoa ou equipe" autoComplete="name" /></label>
              <label className="field"><span>Telefone</span><input value={form.telefone} onChange={(e) => updateField("telefone", e.target.value)} placeholder="(88) 99999-9999" inputMode="tel" /></label>
            </div>
            <div className="form-grid two-columns">
              <label className="field"><span>Bairro ou área *</span><select value={form.bairro} onChange={(e) => setForm((c) => ({ ...c, bairro: e.target.value, rua: "" }))}><option value="">Selecione o bairro</option>{territorios.map((item) => <option key={item.bairro}>{item.bairro}</option>)}</select></label>
              <label className="field"><span>Rua ou localidade *</span><select value={form.rua} onChange={(e) => updateField("rua", e.target.value)} disabled={!form.bairro}><option value="">{form.bairro ? "Selecione a rua" : "Escolha o bairro primeiro"}</option>{streets.map((street) => <option key={street}>{street}</option>)}</select></label>
            </div>
            <div className="form-grid two-columns compact-right">
              <label className="field"><span>Nome do morador</span><input value={form.morador} onChange={(e) => updateField("morador", e.target.value)} placeholder="Opcional" /></label>
              <label className="field"><span>Número</span><input value={form.numero} onChange={(e) => updateField("numero", e.target.value)} placeholder="Nº ou S/N" /></label>
            </div>
            <fieldset className="visit-type-fieldset"><legend>Etapa da visita *</legend><div className="visit-type-grid">{["1ª visita", "2ª visita"].map((tipo) => <label key={tipo} className={`visit-type-card ${form.tipoVisita === tipo ? "selected" : ""}`}><input type="radio" name="tipoVisita" checked={form.tipoVisita === tipo} onChange={() => updateField("tipoVisita", tipo)} /><span>{tipo === "1ª visita" ? "1" : "2"}</span><strong>{tipo}</strong></label>)}</div></fieldset>
            <fieldset className="choice-fieldset"><legend>Situação da visita *</legend><div className="choice-grid">{situacoes.map((status) => <label key={status} className={`choice-card ${form.situacao === status ? "selected" : ""}`}><input type="radio" name="situacao" checked={form.situacao === status} onChange={() => updateField("situacao", status)} /><span className="choice-icon">{status.charAt(0)}</span><span>{status}</span></label>)}</div></fieldset>
            <section className="candidate-section" aria-labelledby="candidate-title">
              <div className="candidate-heading"><div><span className="step-label">Intenção informada</span><h4 id="candidate-title">Candidatos</h4></div><span>Seleção opcional</span></div>
              <div className="candidate-grid">
                <label className="field"><span>Deputado Estadual</span><select value={form.deputadoEstadual} onChange={(e) => updateField("deputadoEstadual", e.target.value)}><option value="">Não informado</option>{candidatos.deputadoEstadual.map((nome) => <option key={nome}>{nome}</option>)}</select></label>
                <label className="field"><span>Deputado Federal</span><select value={form.deputadoFederal} onChange={(e) => updateField("deputadoFederal", e.target.value)}><option value="">Não informado</option>{candidatos.deputadoFederal.map((nome) => <option key={nome}>{nome}</option>)}</select></label>
                <label className="field"><span>Senador</span><select value={form.senador} onChange={(e) => updateField("senador", e.target.value)}><option value="">Não informado</option>{candidatos.senador.map((nome) => <option key={nome}>{nome}</option>)}</select></label>
                <label className="field"><span>Governador</span><select value={form.governador} onChange={(e) => updateField("governador", e.target.value)}><option value="">Não informado</option>{candidatos.governador.map((nome) => <option key={nome}>{nome}</option>)}</select></label>
                <label className="field candidate-president"><span>Presidente</span><select value={form.presidente} onChange={(e) => updateField("presidente", e.target.value)}><option value="">Não informado</option>{candidatos.presidente.map((nome) => <option key={nome}>{nome}</option>)}</select></label>
              </div>
            </section>
            <div className="form-grid two-columns compact-right">
              <label className="field"><span>Precisa de retorno?</span><select value={form.retorno} onChange={(e) => updateField("retorno", e.target.value)}><option>Não</option><option>Sim</option></select></label>
              <div className="field"><span>Localização</span><button className={`location-button ${form.latitude !== null ? "captured" : ""}`} type="button" onClick={captureLocation}>{form.latitude !== null ? "Localização adicionada" : "Usar localização atual"}</button></div>
            </div>
            <label className="field"><span>Observações</span><textarea value={form.observacoes} onChange={(e) => updateField("observacoes", e.target.value)} placeholder="Anote informações importantes para o próximo contato" rows={4} /></label>
            <div className="submit-row"><p>Os dados serão enviados para a aba <strong>Coletas</strong>.</p><button className="button button-primary submit-button" type="submit" disabled={sending}>{sending ? "Enviando…" : "Registrar visita"}</button></div>
          </form>
        </section>

        <aside className="side-column">
          <section className="side-card"><div className="side-card-heading"><div><span className="step-label">Google Sheets</span><h3>Base de registros</h3></div><span className={`mini-status ${connected ? "ok" : ""}`}>{connected ? "Ativa" : "Pendente"}</span></div><p>A planilha contém as ruas cadastradas, configurações e o histórico completo das visitas.</p><a className="sheet-link" href={SHEET_URL} target="_blank" rel="noreferrer">Abrir planilha Google <span>↗</span></a></section>
          <section className="side-card session-card"><div className="side-card-heading"><div><span className="step-label">Agora</span><h3>Envios da sessão</h3></div><span className="session-count">{sentVisits.length}</span></div>{sentVisits.length === 0 ? <div className="empty-state"><div className="empty-icon">✓</div><p>Os registros enviados neste acesso aparecerão aqui.</p></div> : <ul className="visit-list">{sentVisits.map((visit) => <li key={visit.id}><div><strong>{visit.rua}</strong><span>{visit.bairro}</span></div><div className="visit-meta"><span>{visit.tipoVisita} · {visit.situacao}</span><time>{visit.horario}</time></div></li>)}</ul>}</section>
        </aside>
      </div>

      <footer><span>VISITAAE</span><p>Base territorial: 15 bairros/áreas e 442 ruas/localidades.</p></footer>

      {showSetup && <div className="modal-backdrop" role="presentation" onMouseDown={(e) => e.target === e.currentTarget && setShowSetup(false)}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="setup-title">
        <div className="modal-heading"><div><span className="step-label">Configuração da integração</span><h3 id="setup-title">{hasEndpoint ? "Atualizar o Google Sheets" : "Conectar ao Google Sheets"}</h3></div><button className="close-button" type="button" onClick={() => setShowSetup(false)} aria-label="Fechar">×</button></div>
        <ol className="setup-steps"><li><span>1</span><div>Abra a planilha e clique em <strong>Extensões → Apps Script</strong>.</div></li><li><span>2</span><div>Apague o conteúdo, cole o código abaixo e clique em <strong>Salvar</strong>.</div></li></ol>
        <div className="code-box"><div className="code-toolbar"><span>Código da integração</span><button type="button" onClick={copyScript}>{copied ? "Copiado!" : "Copiar código"}</button></div><pre>{appsScriptCode}</pre></div>
        <ol className="setup-steps continued" start={3}><li><span>3</span><div>Clique em <strong>Implantar → Nova implantação → Aplicativo da Web</strong>.</div></li><li><span>4</span><div>Escolha “Executar como eu” e permita acesso a “Qualquer pessoa”. Depois, copie o URL terminado em <strong>/exec</strong>.</div></li></ol>
        <label className="field endpoint-field"><span>URL da implantação</span><input value={endpointDraft} onChange={(e) => setEndpointDraft(e.target.value)} placeholder="https://script.google.com/macros/s/.../exec" /></label>
        <div className="modal-actions"><a className="button button-ghost" href={SHEET_URL} target="_blank" rel="noreferrer">Abrir planilha</a><button className="button button-primary" type="button" onClick={saveEndpoint}>Salvar conexão</button></div>
      </section></div>}
    </main>
  );
}
